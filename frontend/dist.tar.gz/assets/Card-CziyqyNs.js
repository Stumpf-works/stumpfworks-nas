import{j as d,m as e}from"./index-sLiGEHBX.js";function m({children:r,className:a="",hoverable:o=!1}){return d.jsx(e.div,{whileHover:o?{y:-2,boxShadow:"0 10px 40px rgba(0, 0, 0, 0.15)"}:{},className:`bg-white dark:bg-macos-dark-100 rounded-lg shadow-md border border-gray-200 dark:border-gray-700 ${a}`,children:r})}export{m as C};
//# sourceMappingURL=Card-CziyqyNs.js.map
