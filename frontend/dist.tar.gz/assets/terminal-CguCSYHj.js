import{e}from"./index-sLiGEHBX.js";/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=[["path",{d:"M12 19h8",key:"baeox8"}],["path",{d:"m4 17 6-6-6-6",key:"1yngyt"}]],a=e("terminal",o);export{a as T};
//# sourceMappingURL=terminal-CguCSYHj.js.map
