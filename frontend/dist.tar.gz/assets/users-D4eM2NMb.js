import{c as e}from"./index-sLiGEHBX.js";const n={list:async()=>(await e.get("/users")).data,get:async s=>(await e.get(`/users/${s}`)).data,create:async s=>(await e.post("/users",s)).data,update:async(s,t)=>(await e.put(`/users/${s}`,t)).data,delete:async s=>(await e.delete(`/users/${s}`)).data};export{n as u};
//# sourceMappingURL=users-D4eM2NMb.js.map
